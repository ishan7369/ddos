const express = require("express");
const next = require("next");

const dev = process.env.NODE_ENV !== "production";
const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const expressServer = express();
  const server = require("http").Server(expressServer);
  const io = require("socket.io")(server);

  io.on("connect", socket => {
    console.log("socet connected server");
    setInterval(() => {
      socket.emit("news", { hello: "world" });
    }, 1000);
  });

  expressServer.get("*", (req, res) => {
    handle(req, res);
  });

  server.listen(process.env.PORT);
});
