import React, { useEffect, memo } from "react";
import io from "socket.io-client";

const index = memo(() => {
  const socket = io();
  useEffect(() => {
    console.log("in use effect");
    socket.on("news", () => console.log);
  });

  return <div>Hello World</div>;
});

export default index;
