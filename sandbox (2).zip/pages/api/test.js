const test = (req, res) => res.json({ api: "working" });

export default test;
